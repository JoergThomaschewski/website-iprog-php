<?php

/**
 * Simple abstraction for a student.
 * @author Thorsten Hallwas, Jörg Thomaschewski <jt@imut.de>
 */
class Student extends Person
{

    /**
     * @var int
     */
    protected $matriculationNumber;

    /**
     * Student constructor.
     *
     * @param string   $firstName
     * @param string   $lastName
     * @param DateTime $birthday
     * @param int      $matriculationNumber
     */
    public function __construct(
        $firstName,
        $lastName,
        DateTime $birthday,
        $matriculationNumber
    ) {
        parent::__construct($firstName, $lastName, $birthday);
        $this->matriculationNumber = $matriculationNumber;
    }
}