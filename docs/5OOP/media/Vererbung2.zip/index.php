<?php

/*
 * Example abstraction for a professor student relationship including and office and a course.
 * @author Thorsten Hallwas, Jörg Thomaschewski <jt@imut.de>
 */

require_once __DIR__.DIRECTORY_SEPARATOR.'Person.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Professor.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Student.php';

$student = new Student(
    'Hans',
    'Müller',
    new DateTime('1995-03-21'),
    12345678
);

$professor = new Professor(
    'Albert',
    'Zweistein',
    new DateTime('1970-02-01'),
    42,
    'Prof. Dr.'
);


echo "Wir haben den 
     {$professor->getFullNameWithAcademicDegree()} <br>";
?>