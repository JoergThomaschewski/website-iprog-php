<?php

/**
 * Abstraction for a professor.
 * @author Thorsten Hallwas, Jörg Thomaschewski <jt@imut.de>
 */
class Professor extends Person
{

    /**
     * @var integer
     */
    protected $employeeNumber;

    /**
     * @var string
     */
    protected $academicDegree;

    /**
     * Person constructor.
     *
     * @param string   $firstName
     * @param string   $lastName
     * @param DateTime $birthday
     * @param int      $employeeNumber
     * @param string   $academicDegree
     */
    public function __construct(
        $firstName,
        $lastName,
        $birthday,
        $employeeNumber,
        $academicDegree
    ) {
        parent::__construct($firstName, $lastName, $birthday);
        $this->employeeNumber = $employeeNumber;
        $this->academicDegree = $academicDegree;
    }

    /**
     * Returns the employee number.
     *
     * @return int
     */
    public function getEmployeeNumber()
    {
        return $this->employeeNumber;
    }

    /**
     * Returns the academic degree.
     *
     * @return string
     */
    public function getAcademicDegree()
    {
        return $this->academicDegree;
    }

    /**
     * Returns the full name with the degree for references in text.
     *
     * @return string
     */
    public function getFullNameWithAcademicDegree()
    {
        return $this->academicDegree
               .' '
               .$this->firstName
               .' '
               .$this->lastName;
    }
}