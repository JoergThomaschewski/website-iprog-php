<?php
/*
 * Example for class Lecture - Exercise 6.4.4 Vererbung, Task 3
 * @author Jörg Thomaschewski <jt@imut.de>
 */

class Lecture extends Modul           // Unterklasse "Lecture"
{
    protected $lectureName;           // Eigenschaft von "Lecture"

    public function __construct($lectureName)    // Konstruktor von "Lecture"
    {
        $this->lectureName = $lectureName;
        parent::__construct();
    }

    public function getLecture(): string
    {
        return "Die Veranstaltung heißt: '$this->lectureName'";
    }

    public function getLectureWithTeacher(): string
    {
        return "Die Veranstaltung von '$this->teacher' heißt: '$this->lectureName'";
    }

}
