<?php
/*
 * Example for Main program - Exercise 6.4.4 Vererbung, Task 3
 * @author Jörg Thomaschewski <jt@imut.de>
 */

require_once 'Modul.php';
require_once 'Lecture.php';

$lecture = new Lecture("Vorlesung Internetprogrammierung");

echo "{$lecture->getLectureWithTeacher()} <br>";
?>