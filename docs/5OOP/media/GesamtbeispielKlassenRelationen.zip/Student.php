<?php declare(strict_types=1);

/**
 * Simple abstraction for a student.
 */
class Student extends Person
{

    /**
     * @var int
     */
    protected $matriculationNumber;

    /**
     * Student constructor.
     *
     * @param string   $firstName
     * @param string   $lastName
     * @param DateTime $birthday
     * @param int      $matriculationNumber
     */
    public function __construct(
        string $firstName,
        string $lastName,
        DateTime $birthday,
        int $matriculationNumber
    ) {
        parent::__construct($firstName, $lastName, $birthday);
        $this->matriculationNumber = $matriculationNumber;
    }

    /**
     * Returns a sentence that describes the current student is learning the course.
     *
     * @param Course $course
     *
     * @return string
     */
    public function getLearningForCourseSentence(Course $course): string
    {
        return "{$this->getFullName()} is learning "
            ."for course {$course->getName()} "
            ."taught by {$course->getProfessor()->getFullNameWithAcademicDegree()}.";
    }

}