<?php declare(strict_types=1);

/**
 * Abstraction for an office that always belongs to a professor.
 */
class Office
{

    /**
     * @var Professor
     */
    protected $professor;

    /**
     * @var int
     */
    protected $roomNumber;

    /**
     * @var int
     */
    protected $openingHour;

    /**
     * @var int
     */
    protected $closingHour;

    /**
     * Office constructor.
     *
     * @param Professor $professor
     * @param int       $roomNumber
     * @param int       $openingHour
     * @param int       $closingHour
     */
    public function __construct(
        Professor $professor,
        int $roomNumber,
        int $openingHour,
        int $closingHour
    ) {
        $this->professor = $professor;
        $this->roomNumber = $roomNumber;
        $this->openingHour = $openingHour;
        $this->closingHour = $closingHour;
    }

    /**
     * Returns the professor that uses this office.
     *
     * @return Professor
     */
    public function getProfessor(): Professor
    {
        return $this->professor;
    }

    /**
     * Returns the number of the room.
     *
     * @return int
     */
    public function getRoomNumber(): int
    {
        return $this->roomNumber;
    }

    /**
     * Returns whether the office is open at this hour.
     *
     * @param int $hour
     *
     * @return bool
     */
    public function isOpenAtHour(int $hour): bool
    {
        return $this->openingHour < $hour && $hour < $this->closingHour;
    }

    /**
     * Returns a sentence for a student attempting to visit the professor at the given hour.
     *
     * @param Student $student
     * @param int     $hour
     *
     * @return string
     */
    public function getStudentVisitSentence(Student $student, int $hour): string
    {
        $visitSentence = $student->getFullName()
            .' is attempting to visit '
            .$this->professor->getFullNameWithAcademicDegree()
            .' in room '
            .$this->roomNumber
            .' at '
            .$hour
            ." o'clock, ";

        if ($this->isOpenAtHour($hour)) {
            $visitSentence .= 'and '.$this->professor->getFullNameWithAcademicDegree().' is available.';
        } else {
            $visitSentence .= 'but '.$this->professor->getFullNameWithAcademicDegree().' is not available';
        }

        return $visitSentence;
    }

}