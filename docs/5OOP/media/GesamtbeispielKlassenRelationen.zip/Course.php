<?php declare(strict_types=1);

/**
 * Abstraction for a course.
 */
class Course
{

    /**
     * @var string
     */
    protected $name;

    /**
     * @var Professor
     */
    protected $professor;

    /**
     * Course constructor.
     *
     * @param Professor $professor
     * @param string    $name
     */
    public function __construct(Professor $professor, string $name)
    {
        $this->professor = $professor;
        $this->name = $name;
    }

    /**
     * Returns the name of the couse.
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Returns the professor teaching this course.
     *
     * @return Professor
     */
    public function getProfessor(): Professor
    {
        return $this->professor;
    }

}