<?php declare(strict_types=1);

/*
 * Example abstraction for a professor student relationship including and office and a course.
 */

require_once __DIR__.DIRECTORY_SEPARATOR.'Course.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Office.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Person.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Professor.php';
require_once __DIR__.DIRECTORY_SEPARATOR.'Student.php';

$student = new Student(
    'Hans',
    'Müller',
    new DateTime('1995-03-21'),
    12345678
);
$professor = new Professor(
    'Albert',
    'Zweistein',
    new DateTime('1970-02-01'),
    42,
    'Prof. Dr.'
);


$course = new Course($professor, 'Advanced Physics');
$office = new Office($professor, 5, 14, 18);

echo $student->getLearningForCourseSentence($course)."<br>".PHP_EOL;
print $office->getStudentVisitSentence($student, 12)."<br>".PHP_EOL;
print $office->getStudentVisitSentence($student, 15)."<br>".PHP_EOL;