<?php declare(strict_types=1);

/**
 * Beispiel Formular - Daten einlesen
 * @author Jörg Thomaschewski
 * @date 19.04.2019
 */

require_once 'Html.php';
$html = new Html('POST', 'output.php');


echo $html->writeHeaderAndHeadline();
echo $html->startForm();
echo $html->writeInputField("Vorname", "vorname");
echo $html->writeInputField("Name", "nachname");
echo $html->closeFormAndFooter();

