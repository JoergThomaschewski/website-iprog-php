<?php declare(strict_types=1);

class Html
{
    private $method;
    private $url;

    public function __construct(string $method, string $url)
    {
        $this->method = $method;
        $this->url    = $url;
    }

    public function writeHeaderAndHeadline(): string
    {
        return "<!DOCTYPE html>
          <html lang=\"de\">
          <head><title>Formular</title>
          </head>
          <body>
          <h1>Beispielformular</h1>";
    }

    public function startForm(): string
    {
        return "<form method=\"$this->method\" action=\"$this->url\">";
    }

    public function writeInputField(string $text, string $name): string
    {
        return "<label for=\"$name\">$text: </label>
          <input type=\"text\" name=\"$name\" id=\"$name\">
          <br><br>";
    }

    public function closeFormAndFooter(): string
    {
        return "<input type=\"submit\" name=\"button\"  value=\"Formular abschicken\">
          </form>
          </body></html>";
    }
}