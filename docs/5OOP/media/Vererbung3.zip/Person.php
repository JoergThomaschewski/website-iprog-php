<?php declare(strict_types=1);

/**
 * Simple abstraction of a person with firstname, lastname and birthday.
 * @author Thorsten Hallwas, Jörg Thomaschewski <jt@imut.de> 
 */
class Person
{
    /**
     * @var string
     */
    protected $firstName;

    /**
     * @var string
     */
    protected $lastName;

    /**
     * @var DateTime
     */
    protected $birthday;

    /**
     * Person constructor.
     *
     * @param string   $firstName
     * @param string   $lastName
     * @param DateTime $birthday
     */
    public function __construct(
        string $firstName,
        string $lastName,
        DateTime $birthday
    ) {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->birthday = $birthday;
    }

    /**
     * Returns the first name;
     *
     * @return string
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * Returns the last name.
     *
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * Returns the first and last name separated with a space.
     *
     * @return string
     */
    public function getFullName(): string
    {
        return $this->firstName.' '.$this->lastName;
    }

    /**
     * Returns the birthday.
     *
     * @return DateTime
     */
    public function getBirthday(): DateTime
    {
        return $this->birthday;
    }

}