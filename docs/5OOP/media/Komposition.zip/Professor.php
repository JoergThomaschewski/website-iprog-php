<?php declare(strict_types=1);

/**
 * Abstraction for a professor.
 */
class Professor extends Person
{

    /**
     * @var integer
     */
    protected $employeeNumber;

    /**
     * @var string
     */
    protected $academicDegree;

    /**
     * Person constructor.
     *
     * @param string   $firstName
     * @param string   $lastName
     * @param DateTime $birthday
     * @param int      $employeeNumber
     * @param string   $academicDegree
     */
    public function __construct(
        string $firstName,
        string $lastName,
        DateTime $birthday,
        int $employeeNumber,
        string $academicDegree
    ) {
        parent::__construct($firstName, $lastName, $birthday);
        $this->employeeNumber = $employeeNumber;
        $this->academicDegree = $academicDegree;
    }

    /**
     * Returns the employee number.
     *
     * @return int
     */
    public function getEmployeeNumber(): int
    {
        return $this->employeeNumber;
    }

    /**
     * Returns the academic degree.
     *
     * @return string
     */
    public function getAcademicDegree(): string
    {
        return $this->academicDegree;
    }

    /**
     * Returns the full name with the degree for references in text.
     *
     * @return string
     */
    public function getFullNameWithAcademicDegree(): string
    {
        return $this->academicDegree.' '.$this->firstName.' '.$this->lastName;
    }

}