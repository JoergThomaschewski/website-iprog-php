<?php declare(strict_types=1);

require_once 'Course.php';
require_once 'Person.php';
require_once 'Professor.php';

/*
* Klasse Professor instanzieren - also ein Objekt $professor erstellen
*/
$professor = new Professor(
    'Jörg',
    'Thomaschewski',
    new DateTime('1970-02-01'),
    42,
    'Prof. Dr.'
);

/*
* Klasse Course instanzieren - also ein Objekt $course erstellen.
* Klasse 'Course' erhält das zuvor erstellte Objekt $professor.
*/
$course = new Course(
    $professor,
    'Internet-Programmierung'
);

echo "Die Lehrveranstaltung ist '{$course->getName()}' <br>";

echo "Eine Veranstaltung von {$course->getProfessor()->getLastName()} <br>";

echo "Eine Veranstaltung von {$professor->getLastName()} <br>";