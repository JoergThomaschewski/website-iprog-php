<?php declare(strict_types=1);

class Html
{
    private $method;
    private $url;

    public function __construct(string $method, string $url)
    {
        $this->method = $method;
        $this->url    = $url;
    }

    public function writeHeaderAndHeadline(string $title): string
    {
        return "<!DOCTYPE html>
          <html lang=\"de\">
          <head><title>$title</title>
          </head>
          <body>
          <h1>$title</h1>";
    }

    public function startForm(): string
    {
        return "<form method=\"$this->method\" action=\"$this->url\">";
    }

    public function writeInputField(string $text, string $name): string
    {
        return "<label for=\"$name\">$text: </label>
          <input type=\"text\" name=\"$name\" id=\"$name\">
          <br><br>";
    }

    public function writeButton(): string
    {
        return "<input type=\"submit\" name=\"button\"  value=\"Formular abschicken\">
          </form>";
    }

    public function writeFooter(): string
    {
        return "</body></html>";
    }
}