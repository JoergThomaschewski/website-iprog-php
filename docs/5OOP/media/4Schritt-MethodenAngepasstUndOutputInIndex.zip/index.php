<?php declare(strict_types=1);

/**
 * Beispiel Formular - Daten einlesen
 * @author Jörg Thomaschewski
 * @date 19.04.2019
 */

require_once 'Html.php';
$html = new Html('POST', 'index.php');

if (!empty($_POST['button'])) {
    // 2. Seite Daten ausgeben
    echo $html->writeHeaderAndHeadline('Daten ausgeben');
    // Dateiinhalt wird gelöscht
    file_put_contents("output.txt", "");

    // Letztes Element = Button löschen
    array_pop($_POST);

    // Alle anderen POST-Daten mit foreach() auslesen und speichern
    foreach ($_POST as $field => $content) {
        if (!empty($content)) {
            file_put_contents("output.txt", $content, FILE_APPEND);
        }
    }

    echo $html->writeFooter();

// Gespeicherte Datei auslesen
    echo "Es wurden folgende Daten gespeichert:<br>";
    $textOut = file_get_contents("output.txt");
    echo "$textOut";
} else {
    // 1. Seite Formular anzeigen
    echo $html->writeHeaderAndHeadline('Formular');
    echo $html->startForm();
    echo $html->writeInputField("Vorname", "vorname");
    echo $html->writeInputField("Name", "nachname");
    echo $html->writeButton();
    echo $html->writeFooter();
}


