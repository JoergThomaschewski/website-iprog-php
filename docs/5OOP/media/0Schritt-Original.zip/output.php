<?php

/**
 * Beispiel Formular - Daten mit foreach() ausgeben
 * @author Lisa Meijer & Jörg Thomaschewski
 * @date 04.09.2019
 */

function writeHeaderAndHeadline()
{
    echo "<!DOCTYPE html>
          <html lang=\"de\">
          <head><title>Formular</title>
          </head>
          <body>
          <h1>Daten auslesen</h1>";
}

function writeHtmlEnd()
{
    echo "</body></html>";
}


// Beginn des Hauptprogramms
writeHeaderAndHeadline();

// Dateiinhalt wird gelöscht
file_put_contents("output.txt", "");

// Alle POST-Daten mit foreach() auslesen und speichern
foreach ($_POST as $field => $content) {
    if (!empty($content)) {
        file_put_contents("output.txt", $content, FILE_APPEND);
    }
}

// Gespeicherte Datei auslesen
echo "Es wurden folgende Daten gespeichert:<br>";
$textOut = file_get_contents("output.txt");
echo "$textOut";
writeHtmlEnd();
