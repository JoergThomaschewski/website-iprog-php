<?php declare(strict_types=1);

/**
 * Beispiel Formular - Daten einlesen
 * @author Jörg Thomaschewski
 * @date 19.04.2019
 */

require_once 'Html.php';
$html = new Html('POST', 'index.php');

if (!empty($_POST['button'])) {
    echo "Hallo";
} else {
    // 1. Seite Formular anzeigen
    echo $html->writeHeaderAndHeadline();
    echo $html->startForm();
    echo $html->writeInputField("Vorname", "vorname");
    echo $html->writeInputField("Name", "nachname");
    echo $html->closeFormAndFooter();
}


