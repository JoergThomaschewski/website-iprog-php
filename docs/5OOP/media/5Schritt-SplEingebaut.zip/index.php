<?php declare(strict_types=1);

/**
 * Beispiel Formular - Daten einlesen
 * @author Jörg Thomaschewski
 * @date 19.04.2019
 */

require_once 'Html.php';
$filePHP  = "index.php";
$fileSave = "output.txt";

$html = new Html('POST', $filePHP);

if (!empty($_POST['button'])) {
    // 2. Seite Daten ausgeben
    $fileWrite = new SplFileObject($fileSave, "w");

    echo $html->writeHeaderAndHeadline('Daten ausgeben');
    array_pop($_POST);

    // Alle anderen POST-Daten mit foreach() auslesen und speichern
    foreach ($_POST as $field => $content) {
        if (!empty($content)) {
            $fileWrite->fwrite($content);
        }
    }
    $fileWrite = null;

    // $file-Objekt zum Lesen erzeugen
    $fileRead = new SplFileObject($fileSave, "r");

    // Alle Zeilen bis End-of-File =eof() ausgeben
    while (!$fileRead->eof()) {
        echo $fileRead->fgets() . "<br>";
    }
    $fileRead = null;
    echo $html->writeFooter();

} else {
    // 1. Seite Formular anzeigen
    echo $html->writeHeaderAndHeadline('Formular');
    echo $html->startForm();
    echo $html->writeInputField("Vorname", "vorname");
    echo $html->writeInputField("Name", "nachname");
    echo $html->writeButton();
    echo $html->writeFooter();
}


