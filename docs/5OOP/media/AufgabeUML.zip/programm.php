<?php declare(strict_types=1);

/**
 * Simple abstraction of a person with firstname, lastname and birthday.
 * @author Jannis Seemann https://www.udemy.com/course/das-php-bootcamp/
 * Ergänzt von Jörg Thomaschewski
 */

function autoload($className)
{
  if (file_exists("./src/{$className}.php")) {
    require "./src/{$className}.php";
  }
}
spl_autoload_register("autoload");


function drive(DriveInterface $obj)
{
  return $obj->drive("Berlin");
}

$myBike = new Bicycle();
$myCar = new Car(120);
$mySuperCar = new SuperCar(120);

echo drive($myBike) . "<br>";
echo drive($myCar) . "<br>";
echo drive($mySuperCar) . "<br>";

?>
