<?php declare(strict_types=1);

/**
 * Simple abstraction of a person with firstname, lastname and birthday.
 * @author Jannis Seemann https://www.udemy.com/course/das-php-bootcamp/
 * Ergänzt von Jörg Thomaschewski
 */

class Bicycle implements DriveInterface
{

    public function drive(string $location): string
    {
        return "Ein Fahrrad faehrt in {$location}";
    }

}

