<?php

class Content implements ArrayAccess
{
    /**
     * @var string
     */
    public $key;

    /**
     * @var string
     */
    public $title;

    public function offsetExists(string $key): bool
    {
        return isset($this->$key);
    }

    public function offsetGet(string $key): string
    {
        return $this->$key;
    }

    public function offsetSet(string $key, string $value): void
    {
        $this->$key = $value;
    }

    public function offsetUnset(string $key): void
    {
        unset($this->$key);
    }

}
?>
