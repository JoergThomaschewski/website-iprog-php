<?php
/*
 * Example for Main program - Exercise 6.4.4 Vererbung, Task 1
 * @author Jörg Thomaschewski <jt@imut.de>
 */

require_once 'Modul.php';
require_once 'Lecture.php';

$lecture = new Lecture();

echo "{$lecture->getLecture()} <br>";
?>