<?php
/*
 * Example for class Modul - Exercise 6.4.4 Vererbung, Task 1, 2, 3, 4
 * @author Jörg Thomaschewski <jt@imut.de>
 */

class Modul                         // Basisklasse "Modul"
{
    protected $teacher;             // Eigenschaft der Basisklasse

    public function __construct($teacherName)   // Konstruktor der Basisklasse
    {
        $this->teacher= $teacherName;
    }
}