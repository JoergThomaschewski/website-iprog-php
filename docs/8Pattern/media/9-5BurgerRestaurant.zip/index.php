<?php declare(strict_types = 1);

/*
 * Simple burger order software accepting a customers name and a choice of 3 different burgers.
 * @author Thorsten 'stepo' Hallwas
 */

use Strategy\Decorator\CheeseDecorator;
use Strategy\Decorator\CucumberDecorator;
use Strategy\Decorator\OnionDecorator;
use Strategy\Decorator\SaladDecorator;
use Strategy\Decorator\TomatoDecorator;
use Strategy\OrderInterface;
use Strategy\Strategy\FishBurgerPattyStrategy;
use Strategy\Strategy\SeitanBurgerPattyStrategy;
use Strategy\Template\BurgerOrder;
use Strategy\Strategy\BeefBurgerPattyStrategy;
use Strategy\Strategy\ChickenBurgerPattyStrategy;
use Strategy\Strategy\BeanBurgerPattyStrategy;

include __DIR__.'/vendor/autoload.php';
include __DIR__.'/../0-framework/header.php';

if (!empty($_GET['customer']) && !empty($_GET['burger'])) {
    $order = createOrder($_GET['customer'], $_GET['burger'], $_GET['extras']);
    printOrderSummary($order);
} else {
    printOrderForm();
}

include __DIR__.'/../0-framework/footer.php';

/**
 * Creates a new order for the given customer containing the specified burger.
 * @param string     $customer
 * @param string     $burger
 * @param array|null $extras
 * @return OrderInterface
 */
function createOrder(string $customer, string $burger, ?array $extras): OrderInterface
{
    switch ($burger) {
        case 'bean':
            $patty = new BeanBurgerPattyStrategy();
            break;
        case 'beef':
            $patty = new BeefBurgerPattyStrategy();
            break;
        case 'chicken':
            $patty = new ChickenBurgerPattyStrategy();
            break;
        case 'fish':
            $patty = new FishBurgerPattyStrategy();
            break;
        default:
            $patty = new SeitanBurgerPattyStrategy();
    }
    $order = new BurgerOrder($customer, $patty);

    if (is_array($extras)) {
        foreach ($extras as $extra) {
            $order = addExtraToOrder($extra, $order);
        }
    }

    return $order;
}

/**
 * Add the specified extra to the order.
 *
 * @param string         $extraIdentifier
 * @param OrderInterface $order
 * @return OrderInterface
 */
function addExtraToOrder(string $extraIdentifier, OrderInterface $order): OrderInterface
{
    switch ($extraIdentifier) {
        case 'cheese':
            return new CheeseDecorator($order);
        case 'cucumber':
            return new CucumberDecorator($order);
        case 'onion':
            return new OnionDecorator($order);
        case 'salad':
            return new SaladDecorator($order);
        case 'tomato':
            return new TomatoDecorator($order);
        default:
            return $order;
    }
}

/**
 * Print the welcome text and the form.
 */
function printOrderForm()
{
    echo <<<HTML
    <h1>Welcome to Mega-Burger</h1>
    <h2>Please enter your name for the order.</h2>
    <form method="get">
    <input type="text" name="customer" pattern="[a-zA-Z]+"  required />
    <select name="burger">
        <option value="beef" selected>Beef-Burger</option>
        <option value="bean">Bean-Burger</option>
        <option value="chicken">Chicken-Burger</option>
        <option value="fish">Fish-Burger</option>
        <option value="seitan">Seitan-Burger</option>
    </select>
    <select name="extras[]" multiple>
        <option value="cheese">Cheese</option>
        <option value="cucumber">Cucumber</option>
        <option value="onion">Onion</option>
        <option value="salad">Salad</option>
        <option value="tomato">Tomato</option>
    </select>
    <input type="submit" value="Order">
    </form>
    HTML;
}

/**
 * @param OrderInterface $order
 */
function printOrderSummary(OrderInterface $order)
{
    $orderFinishTime = getOrderFinishTime($order->getPreparationTime());
    $price = number_format($order->getPrice() / 100, 2);
    echo <<<HTML
    <p>Thank you {$order->getCustomer()}.</p>
    <p>Your {$order->getName()} will be ready at {$orderFinishTime}.</p>
    <p>It has {$order->getKiloCalories()} kcal.</p>
    <p>Please pay {$price} €.</p>
    <a href="index.php">Another Order</a>
    HTML;
}

/**
 * Formats the preparation time for the Europe/Berlin timezone.
 *
 * @param int $preparationTime
 * @return string
 */
function getOrderFinishTime(int $preparationTime)
{
    $time = time() + $preparationTime;
    $date = DateTime::createFromFormat('U', (string) $time);
    $dateTimeZone = new DateTimeZone('Europe/Berlin');
    $date->setTimezone($dateTimeZone);

    return $date->format('H:i:s');
}
