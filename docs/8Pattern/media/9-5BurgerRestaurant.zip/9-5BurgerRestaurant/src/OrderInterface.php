<?php declare(strict_types = 1);

namespace Strategy;

/**
 * Interface for orders in our restaurant.
 * @author Thorsten 'stepo' Hallwas
 */
interface OrderInterface
{
    /**
     * @return string
     */
    public function getCustomer(): string;

    /**
     * @return string
     */
    public function getName(): string;

    /**
     * @return int
     */
    public function getPrice(): int;

    /**
     * @return int
     */
    public function getPreparationTime(): int;

    /**
     * @return int
     */
    public function getKiloCalories(): int;
}
