<?php declare(strict_types = 1);

/*
 * Simple burger order software accepting a customers name and a choice of various meals.
 * @author Thorsten 'stepo' Hallwas
 */

error_reporting (0);
use Builder\Builder\MenuBuilder;
use Builder\Builder\MenuDirector;
use Builder\Composite\Burger\Factory\BurgerFactory;
use Builder\Composite\Drink\Factory\DrinkFactory;
use Builder\Composite\Fries\Factory\FriesFactory;
use Builder\Composite\Salad\Factory\SaladFactory;
use Builder\OrderInterface;

include __DIR__.'/vendor/autoload.php';
include __DIR__.'/0-framework/header.php';

$customer = $_GET['customer'] ?: '';
$burger = $_GET['burger'] ?: null;
$burgerExtras = $_GET['burgerExtras'] ?: [];
$fries = $_GET['fries'] ?: null;
$friesExtras = $_GET['friesExtras'] ?: [];
$salad = $_GET['salad'] ?: null;
$saladExtras = $_GET['saladExtras'] ?: [];
$drink = $_GET['drink'] ?: null;
$drinkExtras = $_GET['drinkExtras'] ?: [];

if ($customer && ($burger || $fries || $salad || $drink)) {
    $menuDirector = new MenuDirector(
        new BurgerFactory(),
        new DrinkFactory(),
        new FriesFactory(),
        new SaladFactory(),
        new MenuBuilder($customer)
    );

    $order = $menuDirector->createOrder(
        $customer,
        $burger,
        $burgerExtras,
        $fries,
        $friesExtras,
        $salad,
        $saladExtras,
        $drink,
        $drinkExtras
    );

    printOrderSummary($order);
} else {
    printOrderForm();
}

include __DIR__.'/0-framework/footer.php';

/**
 * Print the welcome text and the form.
 */
function printOrderForm()
{
    echo <<<HTML
    <h1>Welcome to Mega-Burger</h1>
    <h2>Please create your order:</h2>
    <form method="get">
        <div class="form-group">
            <label for="customer">Your name</label>
            <input class="form-control" id="customer" type="text" name="customer" required />
        </div><br>
        <div class="form-group">
            <label for="burger">Do you want a burger?</label>        
            <select class="form-control" id="burger" name="burger">
                <option value="" selected>No Burger</option>
                <option value="beef">Beef-Burger</option>
                <option value="bean">Bean-Burger</option>
                <option value="chicken">Chicken-Burger</option>
                <option value="fish">Fish-Burger</option>
                <option value="seitan">Seitan-Burger</option>
            </select>
        </div>
        <div class="form-group">
            <label for="burgerExtras">Do you want extras with your burger?</label><br>             
            <input type="checkbox" name="burgerExtras[]" id="burgerExtras" value="cheese"> Cheese<br>
            <input type="checkbox" name="burgerExtras[]" id="burgerExtras" value="cucumber"> Cucumber<br>
            <input type="checkbox" name="burgerExtras[]" id="burgerExtras" value="onion"> Onion<br>
            <input type="checkbox" name="burgerExtras[]" id="burgerExtras" value="salad"> Salad<br>  
            <input type="checkbox" name="burgerExtras[]" id="burgerExtras" value="tomato"> Tomato<br>
        </div><br>  
        <div class="form-group">
            <label for="fries">Do you want fries?</label>
            <select class="form-control" id="fries" name="fries">
                <option value="" selected>No Fries</option>
                <option value="french">French-Fries</option>    
            </select>
        </div>
        <div class="form-group">
            <label for="friesExtras">Do you want extras with your fries?</label><br>
            <input type="checkbox" name="friesExtras[]" id="friesExtras" value="ketchup"> Ketchup<br>
            <input type="checkbox" name="friesExtras[]" id="friesExtras" value="mayonnaise"> Mayonnaise<br>      
        </div><br>
        <div class="form-group">
            <label for="salad">Do you want a salad?</label>         
            <select class="form-control" id="salad" name="salad">
                <option value="" selected>No Salad</option>
                <option value="salad">Standard Salad</option>    
            </select>
        </div>
        <div class="form-group">
            <label for="saladExtras">Do you want extras with your salad?</label><br>  
            <input type="checkbox" name="saladExtras[]" id="saladExtras" value="vinaigrette"> Vinaigrette<br>
            <input type="checkbox" name="saladExtras[]" id="saladExtras" value="yogurt"> Yogurt Dressing<br>      
        </div><br> 
        <div class="form-group">
            <label for="drink">Do you want something to drink?</label>         
            <select class="form-control" id="drink" name="drink">
                <option value="" selected>Nothing to drink</option>
                <option value="cola">Cola</option>    
                <option value="lemonade">Lemonade</option>    
            </select>
        </div>     
    <button type="submit" class="btn btn-primary">Order</button>
    </form>
    HTML;
}

/**
 * @param OrderInterface $order
 */
function printOrderSummary(OrderInterface $order)
{
    $orderFinishTime = getOrderFinishTime($order->getPreparationTime());
    $price = number_format($order->getPrice() / 100, 2);
    echo <<<HTML
    <p>Thank you {$order->getCustomer()}.</p>
    <p>Your {$order->getName()} will be ready at {$orderFinishTime}.</p>
    <p>It has {$order->getKiloCalories()} kcal.</p>
    <p>Please pay {$price} €.</p>
    <a href="index.php">Another Order</a>
    HTML;
}

/**
 * Formats the preparation time for the Europe/Berlin timezone.
 *
 * @param int $preparationTime
 * @return string
 */
function getOrderFinishTime(int $preparationTime)
{
    $time = time() + $preparationTime;
    $date = DateTime::createFromFormat('U', (string) $time);
    $dateTimeZone = new DateTimeZone('Europe/Berlin');
    $date->setTimezone($dateTimeZone);

    return $date->format('H:i:s');
}
