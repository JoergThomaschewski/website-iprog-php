<?php declare(strict_types = 1);

/**
 * Footer for the program simulating the Burger Restaurant.
 * It also includes
 * @author Thorsten 'stepo' Hallwas
 */

echo <<<HTML
                </div><!-- col -->
            </div><!-- row -->
        </div><!-- container -->
    </body>
</html>
HTML;
