<?php declare(strict_types = 1);

/*
 * Simple burger order software accepting a customers name and a choice of 3 different burgers.
 * @author Thorsten 'stepo' Hallwas
 */

use Decorator\Decorator\CheeseDecorator;
use Decorator\Decorator\CucumberDecorator;
use Decorator\Decorator\OnionDecorator;
use Decorator\Decorator\SaladDecorator;
use Decorator\Decorator\TomatoDecorator;
use Decorator\OrderInterface;
use Decorator\Template\BeefBurgerOrder;
use Decorator\Template\ChickenBurgerOrder;
use Decorator\Template\VeganBurgerOrder;

include __DIR__.'/vendor/autoload.php';
include __DIR__.'/0-framework/header.php';

if (!empty($_GET['customer']) && !empty($_GET['burger'])) {
    $order = createOrder($_GET['customer'], $_GET['burger'], $_GET['extras']);
    printOrderSummary($order);
} else {
    printOrderForm();
}

include __DIR__.'/0-framework/footer.php';

/**
 * Creates a new order for the given customer containing the specified burger.
 * @param string     $customer
 * @param string     $burger
 * @param array|null $extras
 * @return OrderInterface
 */
function createOrder(string $customer, string $burger, ?array $extras): OrderInterface
{
    switch ($burger) {
        case 'beef':
            $order = new BeefBurgerOrder($customer);
            break;
        case 'chicken':
            $order = new ChickenBurgerOrder($customer);
            break;
        default:
            $order = new VeganBurgerOrder($customer);
    }
    if (is_array($extras)) {
        foreach ($extras as $extra) {
            $order = addExtraToOrder($extra, $order);
        }
    }

    return $order;
}

/**
 * Add the specified extra to the order.
 *
 * @param string         $extraIdentifier
 * @param OrderInterface $order
 * @return OrderInterface
 */
function addExtraToOrder(string $extraIdentifier, OrderInterface $order): OrderInterface
{
    switch ($extraIdentifier) {
        case 'cheese':
            return new CheeseDecorator($order);
        case 'cucumber':
            return new CucumberDecorator($order);
        case 'onion':
            return new OnionDecorator($order);
        case 'salad':
            return new SaladDecorator($order);
        case 'tomato':
            return new TomatoDecorator($order);
        default:
            return $order;
    }
}

/**
 * Print the welcome text and the form.
 */
function printOrderForm()
{
    echo <<<HTML
    <h1>Welcome to Mega-Burger</h1>
    <form method="get">
    <h3>What kind of burger would you like?</h3>
    <select name="burger">
    <option value="beef" selected>Beef-Burger</option>
    <option value="chicken">Chicken-Burger</option>
    <option value="vegan">Vegan-Burger</option>
    </select>
    <br><br>
    <h3>Would you like extras?</h3>
    <input type="checkbox" name="extras[]" value="cheese"> Cheese<br>
    <input type="checkbox" name="extras[]" value="cucumber"> Cucumber<br>
    <input type="checkbox" name="extras[]" value="onion"> Onion<br>
    <input type="checkbox" name="extras[]" value="salad"> Salad<br>  
    <input type="checkbox" name="extras[]" value="tomato"> Tomato
    <br><br>      
    <h3>Please enter and your name for the order.</h3>
    <input type="text" name="customer"  required />
    <input type="submit" value="Order">
    </form>
    HTML;
}

/**
 * @param OrderInterface $order
 */
function printOrderSummary(OrderInterface $order)
{
    $orderFinishTime = getOrderFinishTime($order->getPreparationTime());
    $price = number_format($order->getPrice() / 100, 2);
    echo <<<HTML
    <p>Thank you {$order->getCustomer()}.</p>
    <p>Your {$order->getName()} will be ready at {$orderFinishTime}.</p>
    <p>It has {$order->getKiloCalories()} kcal.</p>
    <p>Please pay {$price} €.</p>
    <a href="index.php">Another Order</a>
    HTML;
}

/**
 * Formats the preparation time for the Europe/Berlin timezone.
 *
 * @param int $preparationTime
 * @return string
 */
function getOrderFinishTime(int $preparationTime)
{
    $time = time() + $preparationTime;
    $date = DateTime::createFromFormat('U', (string) $time);
    $dateTimeZone = new DateTimeZone('Europe/Berlin');
    $date->setTimezone($dateTimeZone);

    return $date->format('H:i:s');
}
