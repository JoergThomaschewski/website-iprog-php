<?php declare(strict_types = 1);

namespace Decorator\Template;

use Decorator\OrderTemplate;

/**
 * Representation of a vegan-burger order in a burger restaurant.
 * @author Thorsten 'stepo' Hallwas
 */
class VeganBurgerOrder extends OrderTemplate
{

    /**
     * @return string
     */
    public function getName(): string
    {
        return 'Vegan-Burger';
    }

    /**
     * @return int
     */
    public function getPrice(): int
    {
        return 750;
    }

    /**
     * @return int
     */
    public function getPreparationTime(): int
    {
        return 150;
    }

    /**
     * @return int
     */
    public function getKiloCalories(): int
    {
        return 450;
    }
}
