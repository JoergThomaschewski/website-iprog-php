<?php declare(strict_types = 1);

namespace Decorator\Template;

use Decorator\OrderTemplate;

/**
 * Representation of a chicken burger order in a burger restaurant.
 * @author Thorsten 'stepo' Hallwas
 */
class ChickenBurgerOrder extends OrderTemplate
{

    /**
     * @return string
     */
    public function getName(): string
    {
        return 'Chicken-Burger';
    }

    /**
     * @return int
     */
    public function getPrice(): int
    {
        return 700;
    }

    /**
     * @return int
     */
    public function getPreparationTime(): int
    {
        return 200;
    }

    /**
     * @return int
     */
    public function getKiloCalories(): int
    {
        return 500;
    }

}
