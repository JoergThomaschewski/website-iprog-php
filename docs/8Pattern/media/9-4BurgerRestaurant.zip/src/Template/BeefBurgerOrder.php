<?php declare(strict_types = 1);

namespace Decorator\Template;

use Decorator\OrderTemplate;

/**
 * Representation of a beef-burger order in a burger restaurant.
 * @author Thorsten 'stepo' Hallwas
 */
class BeefBurgerOrder extends OrderTemplate
{

    /**
     * @return string
     */
    public function getName(): string
    {
        return 'Beef-Burger';
    }

    /**
     * @return int
     */
    public function getPrice(): int
    {
        return 850;
    }

    /**
     * @return int
     */
    public function getPreparationTime(): int
    {
        return 300;
    }

    /**
     * @return int
     */
    public function getKiloCalories(): int
    {
        return 550;
    }

}
