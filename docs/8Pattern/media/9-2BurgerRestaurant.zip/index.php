<?php declare(strict_types = 1);

/*
 * Simple burger order software accepting a customers name for a beef burger order.
 * @author Thorsten 'stepo' Hallwas
 */

use DesignPatterns\Order;

include __DIR__.'/src/Order.php';
include __DIR__.'/0-framework/header.php';

if (!empty($_GET['customer'])) {
    $order = createOrder($_GET['customer']);
    printOrderSummary($order);
} else {
    printOrderForm();
}

include __DIR__.'/0-framework/footer.php';

/**
 * Creates a new order for the given customer.
 *
 * @param string $customer
 * @return Order
 */
function createOrder(string $customer): Order
{
    return new Order($customer);
}

/**
 * Prints the form to specify the customers name.
 */
function printOrderForm()
{
    echo <<<HTML
    <h1>Welcome to Mega-Burger</h1>
    <h2>Please enter your name for the order.</h2>
    <form method="get">
    <input type="text" name="customer" required />
    <input type="submit" value="Order" />
    </form>
    HTML;
}

/**
 * Prints the summary of the order.
 *
 * @param Order $order
 */
function printOrderSummary(Order $order)
{
    $orderFinishTime = getOrderFinishTime($order->getPreparationTime());
    $price = number_format($order->getPrice() / 100, 2);
    echo <<<HTML
    <p>Thank you {$order->getCustomer()}.</p>
    <p>Your {$order->getName()} will be ready at {$orderFinishTime}.</p>
    <p>It has {$order->getKiloCalories()} kcal.</p>
    <p>Please pay {$price} €.</p>
    <a href="index.php">Another Order</a>
    HTML;
}

/**
 * Formats the preparation time for the Europe/Berlin timezone.
 *
 * @param int $preparationTime
 * @return string
 */
function getOrderFinishTime(int $preparationTime)
{
    $time = time() + $preparationTime;
    $date = DateTime::createFromFormat('U', (string) $time);
    $dateTimeZone = new DateTimeZone('Europe/Berlin');
    $date->setTimezone($dateTimeZone);

    return $date->format('H:i:s');
}
