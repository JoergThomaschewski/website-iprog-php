<?php declare(strict_types = 1);

namespace DesignPatterns;

/**
 * Representation of an order in a burger restaurant.
 * @author Thorsten 'stepo' Hallwas
 */
class Order
{

    /**
     * Name of the customer.
     * @var string
     */
    protected $customer;

    /**
     * Order constructor.
     * @param string $customer
     */
    public function __construct(string $customer)
    {
        $this->customer = $customer;
    }

    /**
     * @return string
     */
    public function getCustomer(): string
    {
        return $this->customer;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return 'Beef-Burger';
    }

    /**
     * @return int
     */
    public function getPrice(): int
    {
        return 850;
    }

    /**
     * @return int
     */
    public function getPreparationTime(): int
    {
        return 300;
    }

    /**
     * @return int
     */
    public function getKiloCalories(): int
    {
        return 550;
    }

}
