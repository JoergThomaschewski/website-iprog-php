<?php declare(strict_types = 1);

/*
 * Simple burger order software accepting a customers name and a choice of 3 different burgers.
 * @author Thorsten 'stepo' Hallwas
 */

use Template\OrderTemplate;
use Template\Template\BeefBurgerOrder;
use Template\Template\ChickenBurgerOrder;
use Template\Template\VeganBurgerOrder;

include __DIR__.'/src/OrderTemplate.php';
include __DIR__.'/src/Template/BeefBurgerOrder.php';
include __DIR__.'/src/Template/ChickenBurgerOrder.php';
include __DIR__.'/src/Template/VeganBurgerOrder.php';
include __DIR__.'/0-framework/header.php';

if (!empty($_GET['customer']) && !empty($_GET['burger'])) {
    $order = createOrder($_GET['customer'], $_GET['burger']);
    printOrderSummary($order);
} else {
    printOrderForm();
}

include __DIR__.'/0-framework/footer.php';

/**
 * Creates a new order for the given customer containing the specified burger.
 *
 * @param string $customer
 * @param string $burger
 * @return OrderTemplate
 */
function createOrder(string $customer, string $burger): OrderTemplate
{
    switch ($burger) {
        case 'beef':
            $order = new BeefBurgerOrder($customer);
            break;
        case 'chicken':
            $order = new ChickenBurgerOrder($customer);
            break;
        default:
            $order = new VeganBurgerOrder($customer);
    }

    return $order;
}

/**
 * Print the welcome text and the form.
 */
function printOrderForm()
{
    echo <<<HTML
    <h1>Welcome to Mega-Burger</h1>
    <form method="get">
    <h3>What kind of burger would you like?</h3>
    <select name="burger">
    <option value="beef" selected>Beef-Burger</option>
    <option value="chicken">Chicken-Burger</option>
    <option value="vegan">Vegan-Burger</option>
    </select>
    <br><br>
    <h3>Please enter and your name for the order.</h3>
    <input type="text" name="customer"  required />
    <input type="submit" value="Order">
    </form>
    HTML;
}

/**
 * @param OrderTemplate $order
 */
function printOrderSummary(OrderTemplate $order)
{
    $orderFinishTime = getOrderFinishTime($order->getPreparationTime());
    $price = number_format($order->getPrice() / 100, 2);
    echo <<<HTML
    <p>Thank you {$order->getCustomer()}.</p>
    <p>Your {$order->getName()} will be ready at {$orderFinishTime}.</p>
    <p>It has {$order->getKiloCalories()} kcal.</p>
    <p>Please pay {$price} €.</p>
    <a href="index.php">Another Order</a>
    HTML;
}

/**
 * Formats the preparation time for the Europe/Berlin timezone.
 *
 * @param int $preparationTime
 * @return string
 */
function getOrderFinishTime(int $preparationTime)
{
    $time = time() + $preparationTime;
    $date = DateTime::createFromFormat('U', (string) $time);
    $dateTimeZone = new DateTimeZone('Europe/Berlin');
    $date->setTimezone($dateTimeZone);

    return $date->format('H:i:s');
}
