<?php declare(strict_types = 1);

namespace Template;

/**
 * A template for a burger order
 * @author Thorsten 'stepo' Hallwas
 */
abstract class OrderTemplate
{

    /**
     * Name of the customer.
     * @var string
     */
    protected $customer;

    /**
     * Order constructor.
     * @param string $customer
     */
    public function __construct(string $customer)
    {
        $this->customer = $customer;
    }

    /**
     * @return string
     */
    public function getCustomer(): string
    {
        return $this->customer;
    }

    /**
     * @return string
     */
    abstract public function getName(): string;

    /**
     * @return int
     */
    abstract public function getPrice(): int;

    /**
     * @return int
     */
    abstract public function getPreparationTime(): int;

    /**
     * @return int
     */
    abstract public function getKiloCalories(): int;

}
