<?php declare(strict_types = 1);

namespace Factory\Composite\Drink\Decorator;

use Factory\AbstractOrderDecorator;

/**
 * Decorator to add ice to to a drink order.
 * @author Thorsten 'stepo' Hallwas
 */
class IceDecorator extends AbstractOrderDecorator
{

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->order->getName() . ' with ice';
    }

}
